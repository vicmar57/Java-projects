// Foundations of Computer Science S1
// Assignment#4
// Authors: Victor Martinov , Tsur Avneri.
// Author's ID: 307835249 , 308134485

/**
 * 
 * extended class of car.
 * it has all of the qualities car has
 * in addition to a string variable- sponsor name.
 * has the methods: toString,getId,getModel,getYear.
 */
public class RacingCar extends Car {
	private String _sponsorName;
	/**
	 * the constructor for racingCar class.
	 * @param id the id of the car
	 * @param model model of the car
	 * @param year the year the car was made
	 * @param sponosr the sponsor of the racing car
	 */
	public RacingCar(String id, String model, int year, String sponosr) { // constructor of a new racing car
		super(id, model, year);
		if(sponosr!=null)
		{
			_sponsorName=sponosr;
		}
		else 
		{
			_sponsorName= "No sponser";	// if input sponser is null - setting the _sponserName value to "No sponser" as a string.
		}
	}

	/**
	 * returns the id,model,year,and sponsor of the racing car as a string.
	 */
	public String toString() { // returns full details of a specific racing car
		return "RacingCar [sponsorName=" + _sponsorName + " "+ super.toString()+" ]";
	}
}
