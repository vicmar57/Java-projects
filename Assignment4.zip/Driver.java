// Foundations of Computer Science S1
// Assignment#4
// Authors: Victor Martinov , Tsur Avneri.
// Author's ID: 307835249 , 308134485

/**
 * class driver - describes all details about a specific driver.
 * a standard driver's details - full name , license ID , age , array of cars he owns , number of cars he has (maximum of 5).
 * this class contains the methods : Driver (constructor) , toString (returns driver details), 
 * getFullName - (returns the driver's full name) , get age (returns the driver's current age) , getLicenseID (return driver's license ID number)
 * getCars (returns a hard copy of the driver's cars array) , removeCar (removes a given car from the driver's car array) ,
 * addCar (adds a given car to the driver's car array).
 */
public class Driver {
	public final int CARS_LIMIT = 5;

	private String _fullName;
	private String _licenseID;
	private float _age;
	private Car[] _cars;
	private int _carsCounter; 
	/**
	 * constructor for a new driver.
	 * @param fullName sets a new driver's name to be the given full name.
	 * @param licenseID sets a new driver's license ID to the given license ID.
	 * @param age sets the new driver's age to the given age.
	 */
	public Driver(String fullName, String licenseID, float age) { // constructor of a new driver
		if(fullName!=null )
		{
			_fullName = fullName;
		}
		else
		{
			_fullName="null";  // if input full name is null - setting the full name value to "null" as a string.
		}
		if( licenseID!=null)
		{
			_licenseID = licenseID;
		}
		else{
			_licenseID="null"; // if input licenseID is null - setting the licenseID value to "null" as a string.
		}
		if (age >0)
		{
			_age = age;  // if input age is below 0 (illegal input) - setting the age value to 0.
		}
		else
		{
			_age=0;
		}
		_cars = new Car[CARS_LIMIT];
		_carsCounter =0;
	}
	/**
	 * outputs the full details about the driver (full name , license ID , age , array of cars he owns , number of cars he owns).
	 */

	public String toString() { // returns full details of a specific driver
		String str = "Driver [fullName=" + _fullName + ", licenseID=" + _licenseID + ", age=" + _age + ", cars=[";
		for (int i =0 ; i< CARS_LIMIT-1 ; i++) // adds the driver's cars one by one to str.
		{
			if ( _cars[i]!= null)
			{
				str += _cars[i].toString() + ", "; 
			}
			else
			{
				str += "null, ";
			}
		}
		if ( _cars[CARS_LIMIT-1]!= null) // adding of last car's details to str.
		{
			str += _cars[CARS_LIMIT-1].toString() + "]]";
		}
		else
		{
			str += "null]]";
		}
		return (str);
	}
	/**
	 * @return returns the driver's full name.
	 */
	public String getFullName() {
		return _fullName;
	}
	/**
	 * @return returns the driver's current age.
	 */
	public float getAge() {
		return _age;
	}
	/**
	 * @return returns the driver's license ID number.
	 */
	public String getLicenseID() {
		return _licenseID;
	}
	/**
	 * @return returns a copied array of the driver's owned cars.
	 */
	public Car[] getCars() { // returns a copied array of cars the driver owns.
		Car[] carscopy = new Car [CARS_LIMIT]; //a to-be copied array of cars (a copy of _cars).
		for(int i=0;i<CARS_LIMIT;i++)
		{
			if(_cars[i]!=null)
			{
				carscopy[i]= _cars[i];
			}
		}
		return carscopy; //returns copied array.
	}
	/**
	 * @param carID a given car ID to be removed from the driver's car array.
	 * @return returns the new array of driver's car , after removal of a given car from it.
	 */
	public Car[] removeCar(String carID) // removes a specific given car from driver's car array

	{	
		if (carID != null && _carsCounter >= 1)
		{
			for (int i =0 ; i < CARS_LIMIT ; i++)
			{
				if (_cars[i] != null && _cars[i].getId().equals(carID)) // if given carID matches one of the cars in the array - sets that car to null in the array (removing it from array).
				{
					System.out.println("Removing :" + _cars[i].toString() + " from Driver : " + _fullName + " , id: " + _licenseID);
					_cars [i] = null;
					_carsCounter--; // Subtracting 1 of driver's car number
					break;
				}
			}
		}
		return getCars(); // returns copied array
	}
	/**
	 * @param c a given car to be added to the driver's car array.
	 * @return returns the new array of driver's car , after adding of a given car to it.
	 */
	public Car[] addCar(Car c) { // adds a specific given car to driver's car array
		boolean found=false;
		if (c!= null)
		{
			for (int i=0 ; i < CARS_LIMIT ; i++)
			{
				if (_cars[i] != null && c.getId().equals(_cars[i].getId())) // checks if given carID matches one of the cars in the array - which means that car already exists in the array and there is no need of adding it.
				{
					found =true;
					break;
				}
			}
			if (_carsCounter == 5)
			{
				System.out.println("Driver " + _fullName + ", id: " + _licenseID + " has too many cars"); // in case there is no option of adding more cars to the driver (got to max of cars he could own)
			}
			if (found == false)
			{
				int j=0;
				while (j<CARS_LIMIT && _carsCounter < 5)
				{
					if (_cars[j]==null)
					{
						_cars[j] = c; // if there is no car in the array - means a car could be added there - adds it to array.
						_carsCounter++;
						System.out.println("Adding :" + c.toString() + " to Driver : " + _fullName + " , id: " + _licenseID);
						break;
					}
					else
					{
						j++;
					}
				}
			}
		}
		return getCars(); // returns copied array
	}	
}
