// Foundations of Computer Science S1
// Assignment#4
// Authors: Victor Martinov , Tsur Avneri.
// Author's ID: 307835249 , 308134485

/**
 * a class that simulates a parking lot.
 * it contains the variables: string name, int number of parking spots,
 * int number of available parking spots, and an array of the class Car (array of the currently parking cars).
 * has the methods: toString, getName, getNumOfParkingSpots, getNumOfAvailableParkingSpots, receiveCarForParking, releaseCarFromParking
 *
 */
public class ParkingLot {
	private String _name;
	private int _numOfParkingSpots;
	private int _numOfAvailableParkingSpots;
	private Car[] _cars;

	/**
	 * checks if a Car is inside the parking lot
	 * @param c Car
	 * @return true if its in the parking lot,false if its not.
	 */
	private boolean contains (Car c){ // checks if a given car is contained in the currently parked cars array - returns true/false for the proper case
		for(int i=0;i<_cars.length;i++)
		{
			if(_cars[i]!=null && c.getId().equals(_cars[i].getId())) // if given carID matches one of the cars in the array - returns true (is car in contained in the car array)
			{
				return true;
			}
		}
		return false; // returns false if given car in not contained in the car array.
	}
	/**
	 * the constructor for the parking lot class.
	 * @param name -name of the parking lot.
	 * @param maxParkingSpots -the maximum cars the parking lot can handle.
	 */
	public ParkingLot(String name, int maxParkingSpots) { // constructor of a new parking lot
		if(maxParkingSpots>0)
		{
			_numOfParkingSpots=maxParkingSpots;
			_cars=new Car[maxParkingSpots];
			_numOfAvailableParkingSpots=maxParkingSpots;
		}
		else // if input max of parking spots is 0 or less - sets _numOfParkingSpots, _numOfAvailableParkingSpots to 0 ; and parking cars array size to 0.
		{
			_numOfParkingSpots=0;
			_cars=new Car[0];
			_numOfAvailableParkingSpots=0;
		}
		if(name!=null)
		{
			_name=name;
		}
		else{ // if input name is null - setting the name value to "null" as a string.
			name="null";
		}
	}
	/**
	 * @return a string describing the parking lot(name,number of available parking spots and the maximum cars the parking lot can handle).
	 */
	@Override
	public String toString() {
		return "Parking Lot [name="+_name+", numOfAvailableParkingSpots="+_numOfAvailableParkingSpots+"]"; 
	}

	/**
	 * 
	 * @return the name of the parking lot as a string.
	 */
	public String getName() {
		return _name;
	}

	/**
	 * 
	 * @return the number of maximum parking spots the parking lot has.
	 */
	public int getNumOfParkingSpots() {
		return _numOfParkingSpots;
	}

	/**
	 * 
	 * @return the number of available parking spots the parking lot has.
	 */
	public int getNumOfAvailableParkingSpots() {
		return _numOfAvailableParkingSpots;
	}

	/**
	 * adds a car to the parking lot
	 * @param c Car
	 * @return if the car was added successfully-true or false if it wasn't added;
	 */
	public boolean receiveCarForParking(Car c) // returns true if car received for parking successfully , false otherwise.
	{
		if(c!=null)
		{
			if(!contains(c))
			{

				if( _numOfAvailableParkingSpots>0) // can receive car for parking only if the parking has a parking space for it.
				{
					for(int i=0;i<_numOfParkingSpots;i++)
					{
						if(_cars[i]==null)
						{
							_cars[i]=c; // puts the car in the parking spot where there was null.
							System.out.println("Receving  : Car [id="+c.getId()+", model="+c.getModel()+", year="+c.getYear()+"] for parking at Parking Lot [name="+_name+", numOfAvailableParkingSpots="+_numOfAvailableParkingSpots+"]");
							_numOfAvailableParkingSpots--; // Subtracting 1 from available parking spots.
							return true; // returns true if given car received for parking successfully
						}
					}
				}
				System.out.println("Parking Lot [name="+_name+", numOfAvailableParkingSpots="+_numOfAvailableParkingSpots+"] has no parking spots left!");
				return false; // prints "no parking spots left" and returns false if numOfAvailableParkingSpots isn't larger than 0 , meaning car couldn't be received for parking in this parking lot.
			}
			System.out.println("this car is already in the parking lot");
			return false; // returns false because car is already in the parking lot and can't be received for parking again in the same lot.
		}
		return false; // if given car's value is null (not valid car input!).
	}
	/**
	 * removes a car from the parking lot.
	 * @param c Car to remove
	 * @return if the car was removed-true else false.
	 */
	public boolean releaseCarFromParking(Car c) //returns true if car released from parking lot successfully , false otherwise.
	{
		if(c!=null)
		{
			for(int i=0;i<_numOfParkingSpots;i++)
			{
				if(_cars[i]!=null&& _cars[i].getId().equals(c.getId()))
				{
					_cars[i]=null; // placing a null value in the array where the car was released from ("releasing" the car from the array of parked cars). 
					System.out.println("Releasing : Car [id="+c.getId()+", model="+c.getModel()+", year=2012] from parking at Parking Lot [name="+_name+", numOfAvailableParkingSpots="+_numOfAvailableParkingSpots+"]");
					_numOfAvailableParkingSpots++; // adding 1 to numOfAvailableParkingSpots after release of the given car from the parking lot.
					return true;

				}
			}
		}
		return false; // if given car's value is null (not valid car input!).
	}
}
