// Foundations of Computer Science S1
// Assignment#4
// Authors: Victor Martinov , Tsur Avneri.
// Author's ID: 307835249 , 308134485

/**
 * class Racing Driver - extends class Driver and describes all details about a specific racing driver, with additional details : 
 * winLoseRatio (the racing driver's win/lose ratio of his career).
 * this class contains the methods : RacingDriver (builder of a new racing driver) , toString (prints racing driver details).
 */
public class RacingDriver extends Driver {
	private double _winLoseRatio;
	/**
	 * constructor for a new racing driver.
	 * @param fullName sets a new racing driver's name to be the given full name.
	 * @param licenseID sets a new racing driver's license ID to be the given license ID.
	 * @param age sets a new racing driver's age to be the given age.
	 * @param winLoseRatio sets a new racing driver's win/lose ratio of his career,  to be the given win/lose ratio of his career.
	 */
	public RacingDriver(String fullName, String licenseID, float age, double winLoseRatio) { // constructor of a new racing driver
		super(fullName, licenseID, age);
		if (winLoseRatio>0)
		{
			_winLoseRatio = winLoseRatio; 
		}
		else
		{
			_winLoseRatio = 0; // if input win/lose ratio is below 0 (illegal input) - setting the win/lose ratio value to 0.
		}
	}
	/**
	 * outputs the full details about the racing driver (win/lose ratio of his career, full name, age, license ID,
	 * array of cars he owns).
	 * - string builder cars - a string builder to be printed as the cars array of the specific driver.
	 */

	public String toString() { // returns full details of a specific racing driver. 
		StringBuilder cars=new StringBuilder(0);
		Car [] temp = super.getCars(); // gets a copied array of the cars the driver owns.
		for(int i=0;i<4;i++) // adding each car to to string builder "cars" one by one.
		{
			if(temp[i]!=null)
			{
				cars.append( temp[i].toString()+", ");
			}
			else
			{
				cars.append("null, ");
			}
		}
		if(temp[4]!=null)
		{
			cars.append(temp[4].toString()+"] ]");
		}
		else
		{
			cars.append("null]]");
		}
		return "RacingDriver [winLoseRatio=" + _winLoseRatio
				+ ", fullName=" + super.getFullName() + ", age=" + super.getAge()
				+ ", licenseID=" + super.getLicenseID() + ", cars=["
				+ cars;
	}
}
