// Foundations of Computer Science S1
// Assignment#4
// Authors: Victor Martinov , Tsur Avneri.
// Author's ID: 307835249 , 308134485

/**
 * Class GazlanSystem - describes a computerized system for a parking lots owner (a Gazlan)
 * , so he could manage in ownerships.
 *a Gazlan's details - full owner's name , number Of Parking Lots he owns (maximum of 10)
 *, array of parking lots he owns.
 *this class contains the methods : GazlanSystem (constructor of a new system),
 * addParkingLot (returns true if given parking lot added successfully to owner's parking lot array, false otherwise), 
 * removeParkingLot (returns true if given parking lot removed successfully from owner's parking lot array, false otherwise),
 * toString (returns parking lots owner details).
 */

public class GazlanSystem {	
	final int GEZEL_LIMIT = 10;	

	private ParkingLot[] lots;
	private int numberOfParkingLots;
	private String ownerName;

	/**
	 * constructor for a new parking lot owner's system.
	 * @param oName parking lots owner's name.
	 */
	public GazlanSystem(String oName) {//constructor of a new GazlanSystem
		if (oName!=null)
		{
			ownerName = oName;
		}
		else // if input owner name is null - setting the owner name value to "null" as a string.
		{
			ownerName = "null";
		}
		lots = new ParkingLot [GEZEL_LIMIT];
		numberOfParkingLots=0;
	}

	/**
	 * adds a parking lot to a parking lots owner's array.
	 * @param pl - the given parking lot to be added to the array.
	 * @return returns true if given parking lot added successfully , false otherwise.
	 */
	public boolean addParkingLot(ParkingLot pl) //returns true if parking lot added successfully to parking lots array , false otherwise.
	{	
		boolean found=false; // a variable to check if the given parking lot exists in the parking lot array or not.
		if (pl!= null)
		{
			for (int i=0 ; i < GEZEL_LIMIT ; i++)
			{
				if (lots[i] != null && lots[i].getName().equals(pl.getName())) // if the given parking lot exists in the parking lots array.
				{
					found =true; 
					break;
				}
			}
			if (found == false) // if the given parking lot does not exist in the parking lots array (means it could be added to the parking lots array).
			{
				boolean added = false;
				int j=0;
				while (j<GEZEL_LIMIT && numberOfParkingLots <=9)
				{
					if (lots[j]==null)
					{
						added=true;
						lots[j] = pl; // if there is no parking lot in the array - means a parking lot could be added there - adds it to array of parking lots.
						numberOfParkingLots++; // adding 1 to owner's numberOfParkingLots after adding another lot to owner's parking lot array.
						System.out.println("Adding Parking Lot [name=" + lots[j].getName() + ", numOfAvailableParkingSpots=" + lots[j].getNumOfAvailableParkingSpots() + "] to " + ownerName + "'s parking lots system");
						return true; // if parking lot added successfully to parking lots array.
					}
					else
					{
						j++;
					}
				}
				if (added == false)
				{
					System.out.println("No more Parking lots left!");
					return false; // no more space to add another parking lot to the array.
				}
			}
		}
		else // if given parking lot's value is null (not valid parking lot name!)
		{
			return false;
		}
		return false; // if one or more of the conditions does not apply
	}	
	public boolean removeParkingLot(ParkingLot pl) ////returns true if parking lot removed successfully from parking lots array , false otherwise.
	{
		if (pl != null && numberOfParkingLots >= 1) // if pl is a valid parking lot and there are 1 or more of parking lots that can be removed.
		{
			for (int i =0 ; i < GEZEL_LIMIT ; i++)
			{
				if (lots[i] != null && lots[i].getName().equals(pl.getName()) ) // if the given parking lot (pl) exists in the parking lots array.
				{
					System.out.println("Removing Parking Lot [name=" + lots[i].getName() + ", numOfAvailableParkingSpots=" + lots[i].getNumOfAvailableParkingSpots() + "] from " + ownerName + "'s parking lots system");
					lots[i] = null; // placing a null value in the array where the lot was released from ("releasing" the parking lot from the array of parked lots). 
					numberOfParkingLots = numberOfParkingLots-1; // Subtracting 1 from current number of parking lots.
					return true;
				}
			}
		}
		return false; // if given parking lot (pl) value is null (not valid parking lot input!) or there are no more parking lots to remove from the parking lots array.
	}

	/**
	 * outputs the full details about the parking lots owner (full owner's name, details of each lot,  number Of Parking Lots he owns).
	 */
	public String toString() { // returns full details about the specific parking lots owner (Gazlan).		
		String str = "Gazlan System [ownerName=" + ownerName + ",lots=[";
		for (int i =0 ; i< GEZEL_LIMIT-1 ; i++) // adding each parking lot to to string "str" one by one.
		{
			if ( lots[i]!= null)
			{
				str += lots[i].toString() + ", ";  
			}
			else
			{
				str+="null, ";
			}
		}
		if ( lots[GEZEL_LIMIT-1]!= null) // adding of last parking lot's details to str.
		{
			str += lots[GEZEL_LIMIT-1].toString() + "], ";
		}
		else
		{
			str+="null], ";
		}
		str += "numberOfParkingLots=" + numberOfParkingLots + "]";
		return (str);	// returns full details about the specific parking lots owner (Gazlan).		
	}

}
