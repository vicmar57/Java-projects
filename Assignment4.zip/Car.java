// Foundations of Computer Science S1
// Assignment#4
// Authors: Victor Martinov , Tsur Avneri.
// Author's ID: 307835249 , 308134485

/**
 * a class representing a car.
 * each car class contains 
 * string id ,string model and int year
 * has the methods: toString,getId,getModel,getYear.
 */
public class Car {
	private String _id;
	private String _model;
	private int _year;	
	/**
	 * the constructor for Car class
	 * @param id the id of the car
	 * @param model model of the car
	 * @param year the year the car was made
	 */
	public Car(String id, String model, int year) 
	{
		if(id!=null)
		{
			_id=id;
		}
		else
		{
			_id = "null"; // if input id is null - setting the id value to "null" as a string.
		}
		if (model!=null)
		{
			_model=model;
		}
		else
		{
			_model ="null"; // if input model is null - setting the model value to "null" as a string.
		}
		if (year >= 1888)
		{
			_year=year;
		}
		else 
		{
			_year = 1888; // if input year is below 1888 (illegal input) - setting the year value to 1888 (first car ever to be sold).
		}
	}	
	/**
	 * returns the car id model and year as a string
	 */
	public String toString() { // returns full details of a specific car
		return "Car [id="+_id+", model="+_model+", year="+_year+"]";
	}
	/**
	 * 
	 * @return the id of the car
	 */
	public String getId() {
		return _id;
	}
	/**
	 * 
	 * @return the model of the car
	 */
	public String getModel() {
		return _model;
	}
	/**
	 * 
	 * @return the year the car was made
	 */
	public int getYear() {
		return _year;
	}
}
