// Foundations of Computer Science S1
// Assignment#4
// Authors: Victor Martinov , Tsur Avneri.
// Author's ID: 307835249 , 308134485

/**
 * interface Assignment - describes a mathematical assignment to a specific variable).
 * every class that implements interface "Assignment" must contain the methods : 
 * 1. getVar (returns the variable that is assigned to a specific assignment).
 * 2. getValue (returns the value of a specific variable that is assigned to a specific assignment).
 * 3. setValue (sets the value of a specific variable that is assigned to a specific assignment , to a given value).
 */
public interface Assignment {
	public Variable getVar();
	public double getValue();
	public void setValue(double value);
}
