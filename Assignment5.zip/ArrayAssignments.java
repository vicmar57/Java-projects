// Foundations of Computer Science S1
// Assignment#4
// Authors: Victor Martinov , Tsur Avneri.
// Author's ID: 307835249 , 308134485

/**
 * class ArrayAssignments - describes an array of assignments to variables (implements interface Assignments)
 * An ArrayAssignments only component - an array of type assignment.
 * this class contains the methods : ArrayAssignments (empty constructor to default array size - 100), ArrayAssignments (constructor), 
 * valueOf (returns the value of a single , given variable's assignment [if it exists in the existing array of assignments]. returns 0 otherwise)), 
 * addAssignment (adds a new assignment to a variable , to the existing array of assignments). 
 */

public class ArrayAssignments implements Assignments 
{
	private Assignment[] _assignments;
	/**
	 * empty constructor of an array of assignments, to default array size - 100.
	 */
	public ArrayAssignments()
	{
		_assignments=new Assignment[100];
	}
	/**
	 * constructor of a new array of assignments to variables.
	 * @param assignments the given assignments to the current variables.
	 */
	public ArrayAssignments(Assignment[] assignments)
	{
		_assignments=assignments;
	}
	/**
	 * returns the value of a single , given variable's assignment (if , of course, it exists in the existing array of assignments). returns 0 otherwise.
	 * @param var a given variable that contains the value of which the method returns (if, of course, it exists in the existing array of assignments).
	 */
	public double valueOf(Variable var) 
	{
		for(int i=0;i<_assignments.length;i++)
		{
			if(_assignments[i]!=null&& _assignments[i].getVar().getName()==var.getName()) //if the name of var is in the array of assignments.
			{
				return _assignments[i].getValue();
			}
		}
		return 0;
	}
	/**
	 * adds a new assignment to a variable , to the existing array of assignments.
	 * @param assignment a given assignment to a variable that the method adds to the existing array of assignments.
	 */
	public void addAssignment(Assignment assignment) 
	{
		for(int i=0;i<_assignments.length;i++)
		{
			if(_assignments[i]==null||_assignments[i].getVar().getName()== assignment.getVar().getName())
			{
				_assignments[i]=assignment;
				break;
			}
		}
	}
}
