// Foundations of Computer Science S1
// Assignment#4
// Authors: Victor Martinov , Tsur Avneri.
// Author's ID: 307835249 , 308134485

/**
 * interface EVariable - describes a mathematical variable by it's name (described by a single character, as "x" , "y" , "z" etc.)
 * every class that implements interface "Variable" must contain the method : 
 * 1. getName (returns the specific variable's name).
 */
public interface Variable 
{
	public char getName();
}
