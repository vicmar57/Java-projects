// Foundations of Computer Science S1
// Assignment#4
// Authors: Victor Martinov , Tsur Avneri.
// Author's ID: 307835249 , 308134485

/**
 * class Multiplication - describes an arithmetic action of Multiplication between two mathematical expressions (implements interface Expression)
 * A Multiplication's components - mathematical expression#1 (_exp1), mathematical expression#2 (_exp2).
 * this class contains the methods : Multiplication (constructor), 
 * getExp1 (returns the first [left hand side] mathematical expression from the Multiplication Expression), 
 * getExp2 (returns the second [right hand side] mathematical expression from the Multiplication Expression), 
 * evaluate (returns the evaluation of the mathematical result from Multiplication of the two expressions (by their assignment value),
 * derivative (returns the mathematical derivative of the Multiplication expression by a given variable "var"),
 * toString (returns how the action of Multiplication between the two expressions looks mathematically),
 * equals (returns true if a given object (which has to be from type Multiplication) and an Multiplication expression are identical , false otherwise).
 */
public class Multiplication implements Expression
{
	private Expression _exp1;
	private Expression _exp2;
	/**
	 * constructor for a new empty Multiplication expression.
	 */
                                                                              /*	public Multiplication() 
	{
		_exp1 = null;
		_exp2 = null;
	}*/
	/**
	 * constructor for a new Multiplication expression.
	 * @param exp1 sets a new Multiplication's left hand side expression to be given exp1.
	 * @param exp2 sets a new Multiplication's right hand side expression to be given exp2.
	 */
	public Multiplication (Expression exp1 ,Expression exp2)
	{
		_exp1 = exp1;
		_exp2 = exp2;
	}
	/**
	 * @return returns the first [left hand side] mathematical expression from the Multiplication Expression.
	 */
	private Expression getExp1()
	{
		return _exp1;
	}
	/**
	 * @return returns the second [right hand side] mathematical expression from the Multiplication Expression.
	 */
	private Expression getExp2()
	{
		return _exp2;
	}
	/**
	 * returns the evaluation of the mathematical result from Multiplication of the two expressions (by their assignment value).
	 * @param assignments the object that contains the value and assignment for each variable within it.
	 */
	public double evaluate (Assignments assignments)
	{
		if (assignments !=null)
		{
			return _exp1.evaluate(assignments)*_exp2.evaluate(assignments);
		}
		else 
		{
			throw new RuntimeException("VariableExpression - evaluate - not a valid type of Assignments");
		}
	}
	/**
	 * returns the derivative of the Multiplication expression by a given variable "var".
	 * @param var the variable that the Multiplication's expression derivative will be done by.
	 */
	public Expression derivative(Variable var)
	{
		if (var!=null)
		{
			return new Addition(new Multiplication(_exp1.derivative(var), _exp2),new Multiplication(_exp1 ,_exp2.derivative(var))); //derivative done by the mathematical formula for a multiplication's derivative.
		}
		else 
		{
			return new Multiplication(_exp1 , _exp2);
		}
	}
	/**
	 * returns how the action of Multiplication between the two expressions looks mathematically.
	 */
	public String toString() 
	{
		return "(" + _exp1.toString() + "*" + _exp2.toString() + ")";
	}
	/**
	 * returns true if a given object (which has to be from type Multiplication) and a multiplication expression are identical , false otherwise.
	 * @param other other given object to be compared to the specific Multiplication expression, and determine if they are equal.
	 */
	public boolean equals (Object other)
	{
		if (other instanceof Multiplication) 
		{
			return (((Multiplication)other).getExp1().equals(_exp1) && ((Multiplication)other).getExp2().equals(_exp2));
		}
		else
			return false;
	}
}

