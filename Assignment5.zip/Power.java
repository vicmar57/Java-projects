// Foundations of Computer Science S1
// Assignment#4
// Authors: Victor Martinov , Tsur Avneri.
// Author's ID: 307835249 , 308134485

/**
 * class Power - describes an arithmetic action of Power between two mathematical expressions - the base in the power of the exponent (implements interface Expression).
 * A Power's components - base, and it's exponent.
 * this class contains the methods : Power (constructor), 
 * evaluate (returns the evaluation of the mathematical result from Powering the base in the power of the exponent (by their assignment value),
 * derivative (returns the mathematical derivative of the Power expression by a given variable "var"),
 * toString (returns how the action of Powering the  the base in the power of the exponent looks mathematically),
 * equals (returns true if a given object (which has to be from type Power) and a Power expression are identical , false otherwise).
 */
public class Power implements Expression
{
	private Expression _base;
	private double _exponent;
	/**
	 * constructor for a new Power expression.
	 * @param base sets a new Power's left hand side expression to be given base.
	 * @param exponent sets a new Power's right hand side expression to be given exponent.
	 */
	public Power (Expression base, double exponent)
	{
		if(base!=null)
		_base=base;
		_exponent=exponent;
	}
	/**
	 * returns the evaluation of the mathematical result from Powering the base in the power of the exponent (by their assignment value).
	 * @param assignments the object that contains the value and assignment for each variable within it.
	 */
	public double evaluate(Assignments assignments)
	{
		if(assignments!=null)
		return Math.pow(_base.evaluate(assignments),_exponent);
		return 0;
	}
	/**
	 * returns the derivative of the Power expression by a given variable "var".
	 * @param var the variable that the Power's expression derivative will be done by.
	 */
	public Expression derivative(Variable  var)
	{
		if(var!=null)
		{
			if(_exponent!=1)
			return new Multiplication(new Multiplication(new Constant(_exponent), new Power(_base,_exponent-1)), _base.derivative(var)); //derivative done by the mathematical formula for a powered expression's derivative.
			if(_exponent==1)
				return _base.derivative(var);
		}
		return new Constant();
	}
	/**
	 * returns true if a given object (which has to be from type Power) and a Power expression are identical , false otherwise.
	 * @param other other given object to be compared to the specific Power expression, and determine if they are equal.
	 */
	public boolean equals (Object other)
	{
		if (other instanceof Power && other.toString()==toString())
		{
			return true;
		}
		return false;
	}
	/**
	 * returns how the action of Powering the base in the power of the exponent looks mathematically.
	 */
	public String toString()
	{
		return "("+_base.toString()+"^"+_exponent+")";
	}

}
