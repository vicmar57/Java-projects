// Foundations of Computer Science S1
// Assignment#4
// Authors: Victor Martinov , Tsur Avneri.
// Author's ID: 307835249 , 308134485
/**
 * A class representing a variable with value
 * Contains a char for its name.
 * it has the methods:equals,toString,getName,evaluate,derivative
 *
 */
public class VariableExpression implements Variable , Expression {
	private char _name;
	/**
	 * the constructor for the class.
	 * accepts letters only.
	 * @param name - the name of the variable.
	 */
	public VariableExpression (char name){
		if((name>64 && name<91) || (name>96 && name<123))
			_name=name;
	}
	/**
	 * returns a string describing the name(a char)
	 */
	public String toString(){
		return ""+_name;
	}
	/**
	 * checks if the variable received equals to this variable.
	 * @param other - the variable received.
	 * @return true if equal, false if not.
	 */
	public boolean equals (VariableExpression other)
	{
		if(_name==other.getName())
			return true;
		return false;
	}
	/**
	 * @return the name of the variable
	 */
	public char getName(){
		return _name;
	}
	/** the method returns the value of the variable
	 * @return the value(double)
	 */
	public double evaluate(Assignments assignments){
		if(assignments!=null)
			return assignments.valueOf(this);
		return 0;
	}
	/**
	 * the method returns the derivative of the variable according to the received variable.
	 * @return constant 1 if its the same variable else constant 0.
	 */
	public Expression derivative(Variable  var){
		if(var!=null && var.getName()==_name)
			return new Constant(1);
		return new Constant();
	}

}
