// Foundations of Computer Science S1
// Assignment#4
// Authors: Victor Martinov , Tsur Avneri.
// Author's ID: 307835249 , 308134485

/**
 * interface Expression - describes a mathematical expression of any kind (addition, subtraction, multiplication, power, polynomial, a constant).
 * every class that implements interface "Expression" must contain the methods : 
 * 1. evaluate (returns the evaluation of the mathematical result from a mathematical action on two expressions (by their assignment value).
 * 2. derivative (returns the mathematical derivative of a given expression by a given variable "var").
 */
public interface Expression 
{
	public double evaluate(Assignments assignments);
	public Expression derivative(Variable  var);
}
