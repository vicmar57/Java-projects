// Foundations of Computer Science S1
// Assignment#4
// Authors: Victor Martinov , Tsur Avneri.
// Author's ID: 307835249 , 308134485

/**
 * class ValueAssignment - describes all details about a specific assignment to a mathematical variable (implements interface Assignment)
 * A ValueAssignment's components - value (of the specific assignment), a variable.
 * this class contains the methods : ValueAssignment (constructor), 
 * getVar (returns the variable), getValue (returns the variable's value), setValue (sets the variable's value to the given value)
 * toString (returns a string that describes the variable and it's value),
 * equals (returns true if a given object (which has to be from type Variable) and a ValueAssignment expression are identical , false otherwise).
 */
public class ValueAssignment implements Assignment 
{
	private double _value;
	private Variable _var;
	/**
	 * constructor for a new ValueAssignment expression.
	 * @param var sets a new ValueAssignment's variable.
	 * @param value sets a new ValueAssignment's value.
	 */
	public ValueAssignment(Variable var,double value)
	{
		_value=value;
		_var=var;
	}
	/**
	 * returns the variable of the ValueAssignment.
	 */
	public Variable getVar()
	{
		return _var;//cannot change the parameters.
	}
	/**
	 * returns the variable's value.
	 */
	public double getValue()
	
	{
		return _value;
	}
	/**
	 * sets the variable's value to a given value.
	 */
	public void setValue(double value)
	{
		_value=value;
	}
	/**
	 * returns a string that describes the variable and it's value.
	 */
	public String toString()
	{
		return _var+"="+_value;
	}
	/**
	 * @param value other ValueAssignment's value
	 * @param var ValueAssignment's variable
	 * @return returns true if a given object (which has to be from type Variable) and a ValueAssignment expression are identical , false otherwise
	 */
	public boolean equals(double value,Object var)
	{
		if(var instanceof Variable && value==_value && ((Variable)var).getName()==_var.getName()) //compares the values and names of the two expressions
		{
			return true;
		}
		return false;

	}
}
