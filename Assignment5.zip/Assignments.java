// Foundations of Computer Science S1
// Assignment#4
// Authors: Victor Martinov , Tsur Avneri.
// Author's ID: 307835249 , 308134485

/**
 * interface Assignments - describes mathematical assignments to specific variables).
 * every class that implements interface "Assignments" must contain the methods : 
 * 1. valueOf (returns the value of a single , given variable's assignment [if it exists in where we want to find it]. returns 0 otherwise), 
 * 2. addAssignment (adds a new assignment to a variable , to an existing data structure which contains variable assignments). 
 */
public interface Assignments {
	public double valueOf(Variable var);
	public void addAssignment(Assignment assignment);
}
