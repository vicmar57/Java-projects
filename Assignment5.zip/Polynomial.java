// Foundations of Computer Science S1
// Assignment#4
// Authors: Victor Martinov , Tsur Avneri.
// Author's ID: 307835249 , 308134485
/**
 * A class representing a polynomial
 * Contains a variable and a double array
 * it has the methods:evaluate,derivative,toString and equals 
 */
public class Polynomial implements Expression 
{
	private Variable _var;
	private double[] _coefficients;
	/**
	 * the constructor of the class
	 * @param var the variable the polynomial contains
	 * @param coefficients -the coefficients of the polynomial
	 */
	public Polynomial(Variable var, double[] coefficients)
	{
		if(var!=null && coefficients!=null)
		{
			_var=var;
			_coefficients=new double[coefficients.length];
			for(int i=0;i<coefficients.length;i++)
			{
				_coefficients[i]=coefficients[i];
			}
		}
	}
	/** the method calculates the value of the polynomial
	 * @return the value(double)
	 */
	public double evaluate(Assignments assignments)
	{
		double Ans=_coefficients[0];
		if(assignments!=null)
		{
			//Expression ans= new Constant(_coefficients[0]);
			for(int i=1;i<_coefficients.length;i++)
			{
				//ans =new Addition(ans, new Multiplication(new Constant(_coefficients[i]),new Power (new Constant(assignments.valueOf(_var)),i)));
				Ans += _coefficients[i]*(Math.pow(assignments.valueOf(_var), i));
				//new Power (new Constant(assignments.valueOf(_var)),i).evaluate(assignments);
			}
		}
		return Ans;
	}
	/**
	 * @return the derivative of the polynomial according to the variable sent.
	 */
	public Expression derivative(Variable var) 
	{
		double[] mekadmim=new double[_coefficients.length-1];
		if(var!=null && _var.getName()==var.getName())
		{ 
			for(int i=1;i<_coefficients.length;i++)
			{
				//ans=new Addition(ans,new Multiplication( new Constant(_coefficients[i]*i),new Power((VariableExpression)_var,i-1)));
				mekadmim[i-1]=_coefficients[i]*i;
			}
			return new Polynomial(_var,mekadmim);
		}
		return new Constant();
	}
	/**
	 * @return a string describing the polynomial
	 */
	public String toString()
	{
		String ans="(";
		for(int i=0;i<_coefficients.length-1;i++)
		{
			if(i==0)
			{
				ans+=_coefficients[i];
			}
			else if(_coefficients[i]<0)
			{
				ans+=_coefficients[i]+""+_var+"^"+i;
			}
			else
			{
				ans+="+"+_coefficients[i]+""+_var+"^"+i;
			}
		}
		if(_coefficients[_coefficients.length-1]<0)
		{
			ans+=_coefficients[_coefficients.length-1]+""+_var+"^"+(_coefficients.length-1)+")";
		}
		else
		{
			ans+="+"+_coefficients[_coefficients.length-1]+""+_var+"^"+(_coefficients.length-1)+")";
		}
		return ans;
	}
	/**
	 * checks if an expression equals to the polynomial
	 * @param toCheck the expression you compare the polynomial to
	 * @return true if equals,false if not
	 */
	public boolean equals (Object toCheck)
	{
		if (toCheck instanceof Polynomial && toCheck.toString()==toString())
		{
			return true;
		}
		return false;
	}
}
