// Foundations of Computer Science S1
// Assignment#2
// Authors: Victor Martinov , Tsur Avneri.
// Author's ID: 307835249 , 308134485

public class Assignment2 
{
	public static final int COL_NUM=8;
	
	public static int[][] changeTo2dWithParity (int[] encodedData)//turns a given array to a matrix with 9(1 is the parity bit) columns and adds "0"s from the right if needed
	{	
		int[][] newarr=new int [encodedData.length/9][9];
		if (encodedData.length%9==0)
		{
			for (int i=0;i<encodedData.length/9;i++)
			{
				for (int j=0;j<9;j++)
				{
					newarr[i][j]=encodedData[i*9+j];
				}
			}
		}
		return newarr ;
	}

	public static int checkMatrix(int[][] encodedArr)//checks for errors in a given matrix and returns the number of errors(if its a single error changes the bit to 2)
	{
		int rowErrorCount=0,colErrorCount=0,wrongRowIndex=0,wrongColIndex=0;
		for(int i=0;i<encodedArr.length-1;i++)//checking the rows
		{
			if(parityCheck(encodedArr[i])==0)
			{
				rowErrorCount++;
				wrongRowIndex=i;
			}
		}
		for(int j=0;j<8;j++)
		{
			if(checkCol(j,encodedArr)==0)//checking the columns
			{
				colErrorCount++;
				wrongColIndex=j;
			}
		}
		if (rowErrorCount==1 && colErrorCount==1)
		{
			encodedArr[wrongRowIndex][wrongColIndex]=2;
		}
		else if (rowErrorCount>=colErrorCount)
		{                                                 // returns the number of errors counted in the matrix
			return rowErrorCount;
		}
		else if (rowErrorCount<colErrorCount)
		{
			return colErrorCount;
		}

		return rowErrorCount;
	}

	public static int[][] changeTo2d (int[] data)//turns a given array to a matrix with 8 columns and adds "0"s from the right if needed
	{	
		int[][] newarr=new int [data.length/8+1][8];
		if (data.length%8==0)
		{
			for (int i=0;i<data.length/8;i++)
			{
				for (int j=0;j<COL_NUM;j++)
				{
					newarr[i][j]=data[i*8+j];
				}
			}
		}
		else
		{
			for (int i=0;i<(data.length/8+1);i++)
			{
				for (int j=0;j<COL_NUM;j++)
				{
					if(i*8+j<data.length)
					{
						newarr[i][j]=data[(i*8)+j];
					}
					else
					{
						newarr[i][j]=0;
					}
				}
			}
		}
		return newarr ;
	}

	public static int[] matrixToArr(int[][] data)//input:a matrix,output:array with the matrix's data.
	{
		int numberOfRows = data.length,numberOfCols = data[0].length;;
		int[] arrayCount = new int[numberOfRows * numberOfCols];
		for (int row = 0, count = 0; row < numberOfRows; row++) 
		{
			for (int col = 0; col < numberOfCols; col++) 
			{
				arrayCount[count] = data[row][col];
				count++;
			}
		}
		return arrayCount;
	}

	public static int printMenu () // prints the menu for the user to use
	{
		System.out.println("Main Menu:");
		System.out.println("--------------");
		System.out.println("1. Manually enter data to encode");
		System.out.println("2. Automatically generate data to encode");	
		System.out.println("3. Encode data");	
		System.out.println("4. Manually enter data to decode");
		System.out.println("5. Automatically insert artificial errors to data");
		System.out.println("6. Decode data");	
		System.out.println("7. Print original data");	
		System.out.println("8. Print encoded data");	
		System.out.println("9. Exit");	
		int userinput = BasicIO.ReadInteger("Enter choice:", 1, 9); //Receives the user's choice from the suggested menu (from 1 to 9) 
		return (userinput); //returns the user's input value to to main program
	}

	public static boolean checkIfBinary (int [] arr) // checks if a given array is a binary array that consists of "0"s and "1"s
	{
		for (int i=0 ; i< arr.length ; i++)
		{
			if (arr[i] != 0 && arr[i] != 1) // returns false if one of the values in the array isn't binary
				return false;
		}
		return true; // returns true if all values in the array are binary
	}

	public static int[][] ManuallyInputdata(int[][] stringMat) //allows the user to input data strings and saves it as the original or encoded data (depending on what the user asked for in the menu)
	{
		int[] binaryArr = null;
		int i = 0;
		String string;
		stringMat = new int[50][];
		string = BasicIO.ReadString("Enter binary data string (leave empty to finish):"); // lets the user input data strings until the user inputs "space"
		while (string.charAt(0) != ' ') 
		{
			binaryArr = new int[string.length()];
			if (CheckAndConvertToArr(string, binaryArr) == true) // if the user inputs a correct value ("0" or "1") - copies the value to an array in the same length as the input string
			{
				stringMat[i] = binaryArr;
				i++;
			}
			string = BasicIO.ReadString("Enter binary data string (leave empty to finish):");
		}
		return stringMat; // returns only the arrays with correct values ("0" or "1") to the main program
	}

	public static int[][] AutomaticCodeGenerator(int[][] inputData) //allows the user to use the computer to generate automatic data strings using an input number of data strings and size of the longest one
	{
		int numOfStrings = BasicIO.ReadInteger("Enter number of data strings to generate:" ,0 ,50);
		int maxStringSize = BasicIO.ReadInteger("Enter max size of a single data string:");
		inputData = new int [numOfStrings + 1][];
		for (int i = 0; i < numOfStrings; i++) // generates random data arrays in the number of times the user asked ('number of data strings to generate")
		{
			if (maxStringSize!=0)
			{
				int tmp = generateRandomInt(1, maxStringSize+1);
				int[] arr = new int[tmp]; 
				for (int j = 0; j < tmp; j++) 
				{
					arr[j] = generateRandomInt(0, 1); // puts random values in the array 
				}
				inputData[i] = arr; // puts every array with random data inside , to a matrix that contains these arrays
			}
		}
		return inputData; // returns the matrix with random data arrays in it
	}

	public static int generateRandomInt(int smaller, int bigger) // generates random value between 0 and 1 to input in a single "slot' in an array (in func "AutomaticCodeGenerator")
	{
		if (smaller == 0 && bigger == 1) 
		{
			if ((int) (Math.random() * 10) % 2 == 0) // if a random value modulo 2 is 0 - generates "0" , if not , generates "1"
			{
				return 0;
			} else {
				return 1;
			}
		}
		return (int) ((Math.random() * (bigger - smaller) + smaller));
	}

	public static int[] addParity (int[] oriArr) //adds a parity bit to a given array
	{
		int[]parityarr=null;
		int onesCounter=0; // counts the amount of times the char "1" shows up in the array
		parityarr=new int [oriArr.length+1];
		int i=0;
		while( i<oriArr.length)
		{
			parityarr[i]=oriArr[i];
			if(oriArr[i]==1)
				onesCounter++; //if there is a "1" in the array , onescounter adds 1 to itself. 
			i++;
		}  		
		if(i==oriArr.length)
		{
			parityarr[i]=onesCounter%2; // the parity bit is decided by the amount of "1"s in the array - if it's an even number - parity bit will be 0 , otherwise it will be "1"
		}
		return parityarr; // returns a new array with the parity bit included
	}

	public static int[][]addParity2(int[][]oriMat) // adds a row and column of parity bits to a given matrix
	{
		int rowCountOnes,colCountOnes;
		int[][]parityArr=new int[oriMat.length+1][COL_NUM+1];
		for(int i=0;i<parityArr.length;i++)
		{
			rowCountOnes=0;
			for(int j=0;j<9;j++) // builds a new matrix with one more row and one more columns for the column and row parity bits to enter there.
			{
				if(i<parityArr.length-1&&j<8)
				{
					parityArr[i][j]=oriMat[i][j];
					if(oriMat[i][j]==1)
					{
						rowCountOnes++; //as the condition in the one dimensional array
					}
				}
				else 
				{
					parityArr[i][j]=rowCountOnes%2; // decides the parity bit for each row (as the condition for the one dimensional array)
				}
			};
		}
		for(int i=0;i<8;i++)
		{
			colCountOnes=0;
			for (int j=0;j<oriMat.length+1;j++)
			{
				if(j<oriMat.length)
				{
					if(parityArr[j][i]==1)
					{
						colCountOnes++; //as the condition in the one dimensional array
					}
				}
				else
				{
					parityArr[j][i]=colCountOnes%2; // decides the parity bit for each column (as the condition for the one dimensional array)
				}
			}
		}
		return parityArr;
	}

	public static int [] correctArr (int [] arr) // corrects a given array to an array that will divide in 8 without a remainder
	{
		int	numOfCellsToCopy=(arr.length-1); // decides the number of cells to copy from the given array- all of it.
		int [] correctedArr=null;
		if (arr.length % 8 == 0) // if the given array modulo 8 is 0 - just copies the array to new array.
		{
			correctedArr = new int [arr.length + 8];
			for (int i=arr.length-1;i>=0; i--)
			{
				correctedArr [numOfCellsToCopy]=arr[i];
				numOfCellsToCopy--;
			}
		}
		else // if the given array modulo 8 is not 0 - copies the array to new array that will divide evenly in 8, from the end to the start - so that the given array's value won't change (leaves "0"s from the left of the MSB)
		{
			correctedArr = new int [arr.length + (8-(arr.length%8)) + 8];
			for (int i=arr.length-1;i>=0; i--)
			{
				correctedArr [numOfCellsToCopy + (8-arr.length%8)]=arr[i];
				numOfCellsToCopy--;
			}
		}
		return correctedArr; // returns the corrected array
	}

	public static int [] [] turnArrToMatrix0sFromTheLeft (int [] arr) //turns a given array to a matrix with 8 columns and adds "0"s from the left if needed
	{
		int originArrInd=arr.length;
		int [][] matrixArr = new int [arr.length/8+1][8];
		if (arr.length%8 !=0) // if the given array modulo 8 is not 0 - copies the array to new matrix with 8 columns (8 bits per row), from the end to the start - so that the given array's value won't change (leaves "0"s from the left of the MSB)
		{
			for (int i=(arr.length/8);i>=0; i--)
			{
				for (int j=COL_NUM-1 ; j>=0 ; j--)
				{
					if (originArrInd>0)
					{
						matrixArr [i][j] = arr [originArrInd-1];
						originArrInd--;
					}
				}
			}
		}
		else // if the given array modulo 8 is 0 - copies the array to new matrix with 8 columns (8 bits per row), from the end to the start
		{
			matrixArr = new int [arr.length/8][8];
			for (int i=(arr.length/8)-1;i>=0; i--)
			{
				for (int j=COL_NUM-1 ; j>=0 ; j--)
				{
					if (originArrInd>0)
					{
						matrixArr [i][j] = arr [originArrInd-1];
						originArrInd--;
					}
				}
			}
		}
		return (matrixArr); // returns the corrected array in the form of 8 bits per row matrix
	}

	public static int [] binaryAddition (int [] arr1 , int [] arr2) // adds two 8-bit arrays as in binary addition
	{
		int carry = 0;
		int [] addedArr = new int [8]; // Builds a new array that is the result of binary addition of 2 given arrays (that represent two close together rows of an matrix [that represents the original array divided to 8bit rows]) 
		for (int i=7; i>=0; i--)
		{
			if (arr1[i]+arr2[i] +carry ==0)
			{
				carry=0;
				addedArr[i] = 0;
			}
			else if (arr1[i]+arr2[i] +carry ==1)
			{
				carry=0;                       // 
				addedArr[i] = 1;               // calculates the result of binary addition between two bits (a bit in the given array with the matching index bit in the second array)
			}                                  //
			else if (arr1[i]+arr2[i] +carry ==2)
			{
				carry=1;
				addedArr[i] = 0;
			}
			else if (arr1[i]+arr2[i] +carry ==3)
			{
				carry=1;
				addedArr[i] = 1;
			}
		}
		if (carry==1)
		{
			for (int i=7; i>=0; i--)
			{
				if (addedArr[i] +carry ==1)
				{
					carry=0;                  //
					addedArr[i] = 1;          // calculates the result of binary addition between the array with the carry (that was created by the addition in the array itself) , if such carry is not 0.
				}                             //
				else if (addedArr[i] +carry ==2)
				{
					carry=1;
					addedArr[i] = 0;
				}
			}
		}
		return addedArr;
	}

	public static int [] AdditionInMatrix (int [][] matrix) // adds all of the rows in a matrix as in binary addition
	{
		int [] additionresult = new int [8];
		if (matrix.length==1)
		{
			additionresult= matrix[0]; // if the matrix is a one row matrix , the new array will be the same (nothing to add)
		}
		else 
		{
			additionresult= binaryAddition (matrix [0], matrix[1]);
			for (int i=1 ; i<matrix.length-1;i++) // calculates the binary addition of every two 8bit rows in the matrix
			{
				additionresult= binaryAddition (additionresult, matrix[i+1]); // inserts the result of binary addition between all two 8bit rows in the matrix to the binary addition result array
			}
		}
		for (int i=0 ; i<8;i++)
		{
			if (additionresult[i]==0)
			{                                   //
				additionresult[i]=1;            // 
			}                                   // flips the bits in the additionresult array (does the action of complement to 1 , to every bit in the additionresult array)
			else if (additionresult[i]==1)      //
			{                                   // 
				additionresult[i]=0;
			}
		}
		return additionresult; // returns the addition result array with the complement of 1 to it
	}

	public static int [] applyCheckSum1Complement (int [] arr) // adds a checksum 8-bit array to a given array
	{
		int j=0;
		int [] checkSumArr = correctArr(arr);
		int [][] matrixArr=turnArrToMatrix0sFromTheLeft(arr);
		int [] checkSumResult = AdditionInMatrix (matrixArr);
		while(j<8)
		{
			for (int i=checkSumArr.length-8 ; i< checkSumArr.length; i++)
			{
				checkSumArr[i]= checkSumResult[j]; // puts the results of additionresult array with the complement of 1 to it ,to the array that will contain the checksum result.
				j++;
			}
		}
		return (checkSumArr); // returns an array with the original input data ,plus the checksum action result for the input data array
	}

	public static int checkTheChecksum (int [] checksumarray)// checks an array that was encoded with checksum method (adds another 8bit checksum array and checks if the second checksum array is 8bits of "0"s.)
	{
		if (checkIfBinary(checksumarray)==false)
		{
			return -1; //returns "1" if the given array is not binary.
		}
		else 
		{
			int count=0;
			int [] checkthechecksum = applyCheckSum1Complement(checksumarray)	;
			for (int i=checkthechecksum.length-1 ; i>checkthechecksum.length-9; i-- )
			{
				if (checkthechecksum[i]!=0)
				{
					count++;
				}
			}
			if (count ==0) 
			{
				return 1; //returns "1" if the given array has no errors.
			}
			else 
			{
				return 0; //returns "1" if the given array has errors.
			}
		}
	}

	public static boolean checkIfBinaryString(String input) // checks if a given string of data is a binary string
	{
		for (int i = 0; i < input.length(); i++) 
		{
			if(input.charAt(i)!='0'&& input.charAt(i)!='1')
				return false; // returns false is the string does not consist of "1"s and "0"s only
		}
		return true; // returns true if the string consists of "1"s and "0"s only
	}

	public static void String2Array(String string, int[] arr)  // turns a string of given data to an array that contains the same data
	{
		for (int i = 0; i < string.length(); i++) 
		{
			arr[i] = Integer.parseInt(String.valueOf(string.charAt(i))); // inserts the data from a given data string to an array in the same length
		}
	}

	public static boolean CheckAndConvertToArr(String string, int[] binaryArray) // checks and converts a string of data to an array of binary data
	{
		if(checkIfBinaryString(string)==false)
			return false; // returns false is the string does not consist of "1"s and "0"s only , and does not put the input data string in to an array (because data in the string isn't "legal")
		String2Array(string, binaryArray); // converts the input data string in to an array , and returns true if the string consists of "1"s and "0"s only
		return true;
	}

	public static void PrintTheData(int[][] data) // prints the data of a given matrix
	{
		for (int i = 0; i < (data.length) && (data[i] != null); i++) 
		{
			for (int j = 0; j < (data[i].length); j++) 
			{
				System.out.print(data[i][j]);
			}
			System.out.println("");
		}
	}

	public static int parityCheck (int[] encodedArr)//counts the number of ones in an array and compares it to the parity bit.
	{
		int answer=-1, countOnes=0;
		if (encodedArr!=null)
		{
			for(int i=0;i<encodedArr.length-1;i++)
			{
				if(encodedArr[i]==1)
				{
					countOnes++;
				}
			}
			if (encodedArr[encodedArr.length-1]==countOnes%2)
			{
				answer=1;
			}
			else
				answer=0;
		}
		return answer;

	}

	public static int checkCol(int col,int[][] arrToCheck)  //input:number of columns to check, array's address.output:if the coloumn has no mistakes.
	{
		int ans=0,countOnes=0;
		for(int i=0;i<arrToCheck.length-1;i++)
		{
			if(arrToCheck[i][col]==1)
				countOnes++;
		}
		if(countOnes%2==arrToCheck[arrToCheck.length-1][col])//if its ok
			ans=1;
		return ans;
	}

	public static void main(String[] args) 
	{
		int[][] originalArray = null;
		int[][] codedData = null;
		int choice = printMenu();
		while (choice!=9) // allows all choices in the menu while the user doesn't want to leave the program (by pressing "9") 
		{
			switch (choice) 
			{
			case 1:  //in case the user chose "1" - allows the user to input data strings manually and saves it as the original data
				originalArray = ManuallyInputdata(originalArray);	
				choice = printMenu();
				break;
			case 2:  //in case the user chose "2" - allows the user to use the computer to generate automatic data strings ,and saves it as the original data
				originalArray = AutomaticCodeGenerator(originalArray);
				choice = printMenu();
				break;
			case 3:  //in case the user chose "3" - allows the user to select an encoding method to encode the input data, and encodes the data for the user
				System.out.println("Select encoding algorithm:");
				System.out.println("--------------------------------");
				System.out.println("1.Parity bit");
				System.out.println("2.Two dimensional parity check code");
				System.out.println("3.Checksum");
				System.out.println("4.Cancel");
				int option3 = BasicIO.ReadInteger("Enter choice:", 1, 4);
				codedData=new int [originalArray.length][];
				if(option3==1) 
				{
					for (int i =0 ; i<originalArray.length && (originalArray[i] != null); i++)
					{
						codedData[i] = addParity(originalArray[i]);
					}
					choice = printMenu();
				}
				else if(option3==2)
				{
					for (int i =0 ; i<originalArray.length && (originalArray[i] != null); i++)
					{
						codedData[i]= matrixToArr(addParity2(changeTo2d(originalArray[i])));
					}
					choice = printMenu();
				}
				else if(option3==3)
				{
					for (int i =0 ; i<originalArray.length && (originalArray[i] != null); i++)
					{
						codedData[i] = applyCheckSum1Complement(originalArray[i]);
					}
					choice = printMenu();
				}
				else if (option3==4)
				{
					choice = printMenu();
				}
				break;
			case 4: //in case the user chose "4" - allows the user to input data strings ,and saves it as the already encoded data
				codedData = ManuallyInputdata(codedData);
				choice = printMenu();
				break;
			case 5: //in case the user chose "5" - allows the user to use the computer to generate random errors in the data , and saves it as the encoded data
				double prob=BasicIO.ReadDouble("Enter error probability for each bit:",0, 1);
				for (int i =0 ;(codedData[i] != null) && i<codedData.length  ; i++)
				{
					for (int j =0 ;(codedData[i] != null) && j<codedData[i].length  ; j++)
					{
						if (Math.random()<=prob)
						{
							if (codedData[i][j]==0)
							{
								codedData[i][j]=1;
							}
							else
							{
								codedData[i][j]=0;
							}
						}
					}
				}
				choice = printMenu();
				break;
			case 6: //not finished   //in case the user chose "6" - allows the user to select a decoding method to decode the input data, encodes the data for the user and outputs an error report


				System.out.println("Select decoding algorithm:");
				System.out.println("--------------------------------");
				System.out.println("1. Parity bit");
				System.out.println("2. Two dimensional parity check code");
				System.out.println("3. Checksum");
				System.out.println("4. Cancel");
				int option6=BasicIO.ReadInteger("Enter choice:", 1, 4);
				int wrongPackages=0,fixedErrorNum=0;
				double stringsLength=0;
				switch (option6)
				{
				case 1://decode the data in parity bit method and produces an error report
					for(int i=0;i<codedData.length && codedData[i]!=null ;i++)
					{
						int ans=parityCheck(codedData[i]);
						if(ans==0)
						{
							wrongPackages++;
							stringsLength+=codedData[i].length;
						}
					}
					System.out.println("Number of packets with errors:"+wrongPackages);
					if(wrongPackages!=0)
					{
						System.out.println("Average length of erroneous packets:"+(stringsLength/wrongPackages));
					}
					else
					{
						System.out.println("Average length of erroneous packets:"+ 0);
					}
					choice = printMenu();
					break;
				case 2://decode the data in two dimensional parity bit method and produces an error report
					for(int i=0;codedData[i]!=null && i<codedData.length;i++)
					{
						int[][] temp=changeTo2dWithParity(codedData[i]);
						int ans=checkMatrix(temp);
						codedData[i]=matrixToArr(temp);
						if(ans==1)
						{
							wrongPackages++;
							fixedErrorNum++;
							stringsLength+=codedData[i].length;
						}
						else if(ans>1)
						{
							wrongPackages++;
							stringsLength+=codedData[i].length;
						}
					}
					System.out.println("Number of packets with errors:"+wrongPackages);
					if (wrongPackages!=0)
					{
						System.out.println("Average length of erroneous packets:"+(stringsLength/wrongPackages));
					}
					else
					{
						System.out.println("Average length of erroneous packets:"+ 0.0);
					}
					System.out.println("Number of corrected errors:"+fixedErrorNum);
					choice = printMenu();
					break;
				case 3://decode the data in checksum method and produces an error report
					for(int i=0;i<codedData.length && codedData[i]!=null ;i++)
					{
						int ans=checkTheChecksum(codedData[i]);
						if(ans==0)
						{
							wrongPackages++;
							stringsLength = stringsLength + codedData[i].length;
						}
					}
					System.out.println("Number of packets with errors:"+wrongPackages);
					if (wrongPackages!=0)
					{
						System.out.println("Average length of erroneous packets:"+(stringsLength/wrongPackages  ));
					}
					else 
					{
						System.out.println("Average length of erroneous packets:"+0.0);
					}
					choice = printMenu();
				case 4://goes back to the menu
				{
					choice = printMenu();
				}
				break;
				}
				break;
			case 7: //in case the user chose "7" - prints the data that has been input by the user
				PrintTheData(originalArray);
				choice = printMenu();
				break;
			case 8: //in case the user chose "8" - prints the data that has been coded
				PrintTheData(codedData);
				choice = printMenu();
				break;

			}
		}
		if (choice==9);
		{
			System.out.println("Goodbye..."); //  exits the program when user presses "9" in the menu
		}
	}
}
