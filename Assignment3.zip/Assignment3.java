// Foundations of Computer Science S1
// Assignment#3
// Authors: Victor Martinov , Tsur Avneri.
// Author's ID: 307835249 , 308134485

public class Assignment3
{
	public static int printMenu () // prints the menu for the user to use
	{
		System.out.println("Please enter your choice:");
		System.out.println("1) Merge Strings");
		System.out.println("2) Remove Duplicates");
		System.out.println("3) Calculated length of the max increasing set");	
		System.out.println("4) Check partition");		
		System.out.println("0)Exit");	
		int userinput = BasicIO.ReadInteger("", 0, 4); //Receives the user's choice from the suggested menu (from 1 to 9) 
		return (userinput); //returns the user's input value to to main program
	}
	public static boolean ifDivided(int[] weights, int i, int sum,int flag ) { //input:int array ,index(0), and a number to check if the array has numbers that can composite the number
		
		 if (i >= weights.length) 
				return false; 
		 if(sum>0)
		 {
            if(flag+weights[i]==sum)
			  return true;
            if(sum>flag+weights[i])
			return  ifDivided(weights,i+1,sum,flag+weights[i]) || ifDivided(weights, i + 1, sum,flag);  //checking if the sum contains the number as an element
		 }
		 if(sum<0)
		 {
			 if(sum<flag+weights[i])
			 {
				 return  ifDivided(weights,i+1,sum,flag+weights[i]) || ifDivided(weights, i + 1, sum,flag) ;
			 }
		 }
		 if(sum==0 && weights.length>2)
			 return true;
		 return false;
	}
	public static int arrSum(int[] arr,int sum,int from,int to)//returns the sum of an int array.
	{

		if(from<to)
		{
			return arrSum(arr,sum+=arr[from],from+1,to);
		}
		return sum; 
	}
	public static boolean partition(int[] arr)//checks if an array can be divided into 2 groups whose sum is equal.
	{
		if(arrSum(arr, 0, 0, arr.length)%2==1 || arr.length==1)
		{
			return false;
		}
		if(ifDivided(arr,0,arrSum(arr, 0, 0, arr.length)/2,0 ))
		{
			return true;
		}
		return false;
	}
	public static void removeDuplicates(StringBuilder sb, int index)//removes duplicating chars in a string
	{
		if(index<sb.length())
		{
			if(sb.indexOf(sb.substring(index, index+1))!=sb.lastIndexOf(sb.substring(index, index+1)))//if the first appearance of a char is not the last appearance of that char
			{
				sb.deleteCharAt(sb.lastIndexOf(sb.substring(index, index+1)));
				removeDuplicates(sb, index);
			}
			removeDuplicates(sb, index+1);
		}
	}
	public static void mergeStringBuilders(StringBuilder sb1,StringBuilder sb2,StringBuilder sb3)//merge 2 string builders into 1
	{
		if(sb1.length()!=0&&sb2.length()!=0)
		{
			if(compareCharToString(sb1.charAt(0),sb2.toString(),0))
			{
				sb3.deleteCharAt(0);
				sb3.append(sb1.charAt(0));
				sb1.deleteCharAt(0);
			}
			else
			{
				sb3.deleteCharAt(0);
				sb3.append(sb2.charAt(0));
				sb2.deleteCharAt(0);
			}
			mergeStringBuilders(sb1,sb2,sb3);
		}
		else
		{
			if(sb1.length()==0&&sb2.length()!=0)
			{
				sb3.delete(0, sb2.length());
				sb3.append(sb2);
			}
			if(sb2.length()==0&&sb1.length()!=0)
			{
				sb3.delete(0, sb1.length());
				sb3.append(sb1);
			}
		}

	}
	public static boolean compareCharToString(char letter,String str,int index)//return true if the char has the lowest value in ASCII compared to the string
	{
		if(index<str.length())
		{
			if(letter<=str.charAt(index))
				return true;
			else
				compareCharToString(letter,str,index+1);
		}
		return false;
	}
	public static boolean checkIfSorted(String str, int index) //checking if a given string is sorted from small to bigger
	{
		if (str.charAt(index) <= str.charAt(index + 1)) 
		{
			if (index == str.length()-2)
			{
				return true;
			}
		}
		else
			return false;
		return checkIfSorted(str, index + 1);
	}
	public static boolean mergeStrings(String str1, int index1, String str2, int index2, StringBuilder sb)//merge 2 strings into 1 string 
	{
		sb.setLength(str1.length()+str2.length());
		index1=0;
		index2=0;
		StringBuilder sb1= new StringBuilder(str1);
		StringBuilder sb2= new StringBuilder(str2);
		boolean ans=checkIfSorted(str1,index1)&&checkIfSorted(str2,index2);
		if(ans)//if both strings are sorted
		{
			mergeStringBuilders(sb1,sb2,sb);
			return ans;
		}
		sb.setLength(0);
		return ans;
	}
	public static boolean isConvertable(String str) //checks if an array contains arithmetic signs , and numbers only
	{
		return isConvertable(str,0);
	}
	public static boolean isConvertable(String str,int i) //checks if an array contains arithmetic signs , and numbers only
	{
		String space =new String(" ");
		if (i==str.length())
		{
			return true;
		} //Stop condition

		if(Character.isDigit(str.charAt(i))||str.charAt(i)==space.charAt(0)||str.charAt(i)=='+'&&i==0||str.charAt(i)=='-'&&i==0
				||str.charAt(i)=='-'&&str.charAt(i-1)==space.charAt(0)||str.charAt(i)=='+'&&str.charAt(i-1)==space.charAt(0)) //If(str.charAt(i)!=.*\\d.*))// Contains a number or spaces //||str.charAt(i)==space.charAt(0)
		{  
			return isConvertable(str,i+1);	
		}
		else
		{
			return false;// Does not contain a number
		}
	}
	public static int CountWords(String str)//counts the amount of numbers a string contains
	{
		return CountWords(str, 0,0);
	}
	public static int CountWords(String str, int count , int numlength)//counts the amount of numbers a string contains
	{
		if (str.length()==0)
			count=0;
		else if (str.charAt(0)< 58 && str.charAt(0)> 47)
		{
			if (numlength>0)
			{
				numlength++;
				count = CountWords(str.substring(1), 0 , numlength);
			}
			else 
			{
				numlength++;
				count = 1 + CountWords(str.substring(1), 0 , numlength);
			}
		}
		else
		{
			numlength=0;
			count = CountWords(str.substring(1) , 0 , numlength);
		}
		return count ;
	}
	public static int[] stringToIntArr(String str)//converts a string into an array
	{
		int [] reik = new int [CountWords(str, 0,0)];
		return stringToIntArr(str,reik,0,0);
	}
	public static int [] stringToIntArr(String str, int [] StrToArray, int Index, int count)//converts a string into and array
	{                                                                         
		if (str.length()!=0 && (str.charAt(0)< 58 && str.charAt(0)> 47 || str.charAt(0)==45))
		{                                   //<=9                 //>=0             //="-" 
			if (count>=0)
			{
				if (str.charAt(0)==45)
				{
					StrToArray[Index] = -1 ; // if the arithmetic sign is a minus , makes the array in Index position to be -1. , and repeats recursion
					count++;
					StrToArray = stringToIntArr(str.substring(1), StrToArray, Index , count); // repeats recursion after removing the first value in the string
				}
				else if (StrToArray[Index]<0 && str.charAt(0)==48 && count<=1) // if the array in the the current index is negative , and the number size is <=1, and the next int in the string is 0 , doesn't take the zero into account.
				{
				StrToArray = stringToIntArr(str.substring(1), StrToArray, Index , count);	
				}
				else
				{
					if (StrToArray[Index]>=0)
					{
						StrToArray[Index]= StrToArray[Index]*10 + ((str.charAt(0)-48)); // if value in the array is positive , than adds next int value from the string to the value in the array
						count++; // indicates the size of current number we are handling with in the given string
						StrToArray = stringToIntArr(str.substring(1), StrToArray, Index , count); // repeats recursion after removing the first value in the string
					}
					else if (count==1)
					{
						StrToArray[Index]= (str.charAt(0)-48)*(-1); // if the value is a single int , and has a minus before it , puts the negative value of the int in the array
						count++;
						StrToArray = stringToIntArr(str.substring(1), StrToArray, Index , count); // repeats recursion after removing the first value in the string
					}
					else
					{
						StrToArray[Index]= StrToArray[Index]*10 - ((str.charAt(0)-48)); // if the current number size in the string is bigger than 1 (count>1), than substracts next int value from the string from the value in the array
						count++;
						StrToArray = stringToIntArr(str.substring(1), StrToArray, Index , count); // repeats recursion after removing the first value in the string
					}
				}
			}
		}
		else if (str.length()!=0) // if we haven't reached full length of the string but we came across with a character that does not symbolize an integer or a "-" 
		{
			if (count>0) 
			{
				count=0; // resets the number size's counter and repeats recursion , moving the index in the array to be the next index.
				StrToArray = stringToIntArr(str.substring(1), StrToArray, Index+1, 0);
			}
			else if (count==0 || str.charAt(0)==43) // if "+" or number size is 0
			{
				StrToArray = stringToIntArr(str.substring(1), StrToArray, Index, 0); // repeats recursion with next char , and resets counter to 0.
			}
		}
		return (StrToArray); // returns the array which consists of number from the given string.
	}
	public static int findMax(int[] a, int index)//finds the biggest number in an array of numbers.
	{
		if (index > 0) {
			return Math.max(a[index], findMax(a, index-1));
		} 

		else {
			return a[0];
		}
	}
	public static int maxSet(int [] Array, int[] SubSeq , int i , int j)// returns the length of the longest increasing sub-sequence in a given array
	{
		if (j == Array.length -1) // stop condition - if we finished proccessing the information in the array and inserting all longest subsequences lengths to subseq array. 
		{
			return findMax (SubSeq , SubSeq.length-1); // will return the max number in subsequences lengths array, which is the longest increasing subsequence in the given array.
		}
		else 
		{
			if (Array[i]>Array[j] && SubSeq [i] < SubSeq[j]+1) // checks if the value in a certain index is bigger than the value at a different index (which is behind the I always) , and that the subsequence length at i is smaller than in (J )+1
			{
				SubSeq [i] = SubSeq[j]+1; // adds the value of subsequence length to value in I to be value in (J) +1
				if (i==j+1 && i+1!=Array.length) // if the value of J +1 reached to I , and I if smaller than given array length , moves I to be I+1 and does the recursion again
				{
					maxSet(Array, SubSeq , i+1 ,0);
				}
				else 
					maxSet(Array, SubSeq , i ,j+1); // if the condition above doesn't apply , moves J to be J +1 and repeats recursion
			}
			else 
				if (i>j+1) // if the value of subseq in I isn't smaller than the value in J  +1 , moves J to be J +1 and repeats recursion
					maxSet(Array, SubSeq , i ,j+1);
				else if (i+1!=Array.length) // if not , and I hasn't reached given array length , than moves I to be I +1 , and resets J to 0, to start over.
				{
					maxSet(Array, SubSeq , i+1 ,0);
				}
				else
				{
					maxSet(Array, SubSeq , i ,j+1); // if I points to the last index in the given array , moves only J to be J +1 and repeats recursion
				}
			return (findMax(SubSeq , SubSeq.length-1)+1); // return the maximum value of the values in subseq array, which is the longest increasing subsequence in the given array.
		}
	}
	public static void main(String[] args) // activates main menu
	{
		int choice = printMenu();
		while (choice!=0) // allows all choices in the menu while the user doesn't want to leave the program (by pressing "9") 
		{
			switch (choice) 
			{
			case 1:  //in case the user chose "1" - allows the user to merge 2 sorted strings into 1 sorted string
				StringBuilder sb=new StringBuilder(0);
				String str1 = BasicIO.ReadString("Enter first string:\n"); // lets the user input a string of data until the user inputs "Enter"
				String str2 = BasicIO.ReadString("Enter second string:\n"); // lets the user input a string of data until the user inputs "Enter"
				if (mergeStrings(str1, 0, str2, 0, sb))
				{
					System.out.println("Answer:\n"+sb);
				}
				else 
				{
					System.out.println("Answer: \nInput incorrect!");
				}
				System.out.println("");
				choice = printMenu();
				break;
			case 2:  //in case the user chose "2" - removes chars that repeat in an array
				String option2 = BasicIO.ReadString("Enter string:\n"); // lets the user input a string of data until the user inputs "Enter"
				StringBuilder op2=new StringBuilder(0);
				op2.append(option2);
				removeDuplicates( op2, 0);
				System.out.println("Answer:\n" + op2);
				choice = printMenu();
				break;
			case 3:  //in case the user chose "3" - returns the longest increasing subsequence of numbers in a given series of numbers
				String Op3 = BasicIO.ReadString("Please enter values for the array (in one row):\n"); // lets the user input a string of data until the user inputs "Enter"
				while (isConvertable(Op3) == false)
				{
					System.out.println("Input incorrect! Please try again.");
					Op3 = BasicIO.ReadString("Please enter values for the array (in one row):\n");
				}
				int [] UserInputArray = new int [CountWords(Op3)];
				int [] SubSeq = new int [CountWords(Op3)];
				SubSeq = stringToIntArr(Op3);
				if (maxSet(SubSeq, UserInputArray , 1 , 0)==0)
					System.out.println("Answer: 1");
				else
					System.out.println("Answer: " + maxSet(SubSeq, UserInputArray , 1 , 0));
				System.out.println("");
				choice = printMenu();
				break;
			case 4:  //in case the user chose "4" - asks the user for a string of numbers and returns if the numbers can be divided into 2 groups whose some is equal
				String op4 = BasicIO.ReadString("Please enter values for the array (in one row):\n"); // lets the user input a string of data until the user inputs "Enter"
				while (isConvertable(op4) == false)
				{
					System.out.println("Input incorrect! Please try again.");
					op4 = BasicIO.ReadString("Please enter values for the array (in one row):\n");
				}
				if( partition(stringToIntArr(op4)))
				{
					System.out.println("Answer: Yes\n");
				}
				else
				{
					System.out.println("Answer: No\n");
				}
				choice = printMenu();
				break;
			}
		}
		if (choice==0);//  exits the program when user presses "0" in the menu
		{
			System.out.println("Bye Bye�"); 
		}
	}
}
