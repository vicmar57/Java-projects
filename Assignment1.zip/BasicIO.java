
import java.io.*;
public class BasicIO {
	/**
	 * 
	 * This class allows you to handle some primitive I/O console operations.
	 *
	 */

	/**
	 * This method reads string with a message
	 * @param message A message printed to the screen before reading.
	 * @return The string read from the user 
	 */
	public static String ReadString(String message)
	{
		boolean isCorrectInputFlag = false;
		String result = null;

		do
		{
			try
			{
				System.out.print(message);
				result = ReadString();

				if ((result.trim() != null) && (result.trim() != ""))
				{
					isCorrectInputFlag = true;
				}
				else
				{
					System.out.println("Error! You have to enter a string. Please try again.");
					isCorrectInputFlag = false;
				}
			}//try
			catch (IOException e)
			{
				isCorrectInputFlag = false;
				System.out.println("Error! IOException. Please try again.");
			}//catch

		}
		while (!isCorrectInputFlag);//end do

		return result;
	}

	/**
	 * This method reads integer numbers with a message
	 * @param message A message printed to the screen before reading.
	 * @return The integer read from the user.
	 */
	public static int ReadInteger(String message)
	{
		int result = 0;						// temp variable for result
		boolean isCorrectInputFlag = false; // flag for successfull finish
		String tmpValue;		

		//Catching error exceptions while user enters the number
		do
		{
			try
			{
				System.out.print(message);
				result = ReadInteger();				
				isCorrectInputFlag = true;
			}				
			catch (NumberFormatException e)
			{
				// Error message for wrong number format exceptions
				System.out.println("Error! Wrong data format. Please try again.");
				isCorrectInputFlag = false;
			}
			catch (IOException e)
			{
				// Error message for incorrect input exceptions
				isCorrectInputFlag = false;
				System.out.println("Error! I\\O exception. Please try again.");
			}

		}
		while (!isCorrectInputFlag);//end do

		return (result);
	}//ReadInteger(String message)

	/**
	 * This method reads integers between two numbers with a message
	 * @param message A message printed to the screen before reading.
	 * @param minValue The minimum value of integer to be read
	 * @param maxValue The maximum value of integer to be read
	 * @return The integer read from the user.
	 */
	public static int ReadInteger(String message, int minValue, int maxValue)
	{
		boolean isCorrectInput = false;
		int userInput=0; //have to be initialized or there is a compile time error.

		do
		{
			System.out.print(message);
			try
			{
				userInput = ReadInteger();
				//Check range
				if ( (userInput >= minValue) && (userInput <= maxValue) )
				{
					isCorrectInput = true;
				}
				else
				{
					isCorrectInput = false;
					System.out.println("Error! Your input should be in range of [" + minValue + "," + maxValue + "]. Please try again.");
				}
			}
			catch (NumberFormatException e)
			{
				isCorrectInput = false;
				System.out.println("Error! Wrong data format. Please try again.");
			}
			catch (IOException e)
			{
				isCorrectInput = false;
				System.out.println("Error! IOException. Please try again.");
			}//end of try block

		}while (!isCorrectInput);

		return userInput;
	}//ReadInteger(String message, int minValue, int maxValue)

	/**
	 * This method reads double numbers with a message
	 * @param message A message printed to the screen before reading.
	 * @return The double read from the user.
	 */
	public static double ReadDouble(String message)
	{
		double result = 0.0;				// temp variable for result
		boolean isCorrectInputFlag = false; // flag for successfull finish
		String tmpValue;		

		//Catching error exceptions while user enters the number
		do
		{
			try
			{
				System.out.print(message);
				result = ReadDouble();				
				isCorrectInputFlag = true;
			}				
			catch (NumberFormatException e)
			{
				// Error message for wrong number format exceptions
				System.out.println("Error! Wrong data format. Please try again.");
				isCorrectInputFlag = false;
			}
			catch (IOException e)
			{
				// Error message for incorrect input exceptions
				isCorrectInputFlag = false;
				System.out.println("Error! I\\O exception. Please try again.");
			}
		}
		while (!isCorrectInputFlag);//end do

		return (result);
	}//ReadDouble(String message)

	/**
	 * This method reads double between two numbers with a message
	 * @param message A message printed to the screen before reading.
	 * @param minValue The minimum value of double to be read
	 * @param maxValue The maximum value of double to be read
	 * @return The double read from the user.
	 */
	public static double ReadDouble(String message, double minValue, double maxValue)
	{
		boolean isCorrectInput = false;
		double userInput = 0.0; //have to be initialized or there is a compile time error.

		do
		{
			System.out.print(message);
			try
			{
				userInput = ReadDouble();
				//Check range
				if ( (userInput >= minValue) && (userInput <= maxValue) )
				{
					isCorrectInput = true;
				}
				else
				{
					isCorrectInput = false;
					System.out.println("Error! Your input should be in range of [" + minValue + "," + maxValue + "]. Please try again.");
				}
			}
			catch (NumberFormatException e)
			{
				isCorrectInput = false;
				System.out.println("Error! Wrong data format. Please try again.");
			}
			catch (IOException e)
			{
				isCorrectInput = false;
				System.out.println("Error! IOException. Please try again.");
			}//end of try block

		}while (!isCorrectInput);

		return userInput;
	}//ReadDouble(String message, double minValue, double maxValue)


	/**
	 * This method pauses the screen and waits for an enter.
	 */
	public static void PauseScreen()
	{
		System.out.print("\nPress <RETURN> to continue.");
		try
		{
			BasicIO.ReadString();
		}
		catch (IOException e)
		{
		}
	}//pauseScreen()	

	/**
	 * This function pauses the screen with a message and waits for and enter.
	 * @param str The message printed to the screen while pausing.
	 */
	public static void PauseScreen(String str)
	{
		System.out.print(str);
		try
		{
			BasicIO.ReadString();
		}
		catch (IOException e)
		{
		}
	}//pauseScreen(String str)

	/**
	 * This method pauses a screen for a number of seconds
	 * @param seconds Number of seconds to paues.
	 */
	public static void PauseScreen(double seconds)
	{
		int delay = (int)(seconds * 1000);
		try 
		{
			Thread.sleep(delay);
		}
		catch (InterruptedException e)
		{
		}		
	}//pauseScreen(double seconds)

	/**
	 * This method clears a screen
	 */
	public static void ClearScreen()
	{
		//supposed there are 24 lines
		for (int i=0;i<24;i++)
		{
			System.out.println();
		}
	}//clearScreen()

	/**
	 * Private methods. For internal use !!!
	 * @return string read from user
	 * @throws IOException
	 */
	private static String ReadString() throws IOException
	{
		String str = "";
		char key;

		do
		{
			key = (char)System.in.read();

			if ((key != '\n') && (key != '\r'))
			{
				str = str + key;
			}//if
		}
		while ((key != '\n') && (key != '\r'));//end do

		if (System.in.available() > 0)
		{
			System.in.read();
		}//if

		return str;
	}//ReadString()

	/**
	 * Private methods. For internal use !!!
	 * @return The integer read.
	 * @throws IOException
	 */
	private static int ReadInteger() throws IOException
	{
		return (Integer.valueOf(ReadString())).intValue();
	}//ReadInteger()

	/**
	 * Private methods. For internal use !!!
	 * @return The integer read.
	 * @throws IOException
	 */
	private static double ReadDouble() throws IOException
	{
		return (Double.valueOf(ReadString())).doubleValue();
	}//ReadNumber()	



}
