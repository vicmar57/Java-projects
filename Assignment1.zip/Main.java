
public class Main {

	// Foundations of Computer Science S1
	// Assignment#1
	// Authors: Victor Martinov , Tsur Avneri.
	// Author's ID: 307835249 , 308134485

	static int printmenu() {//Displays the menu.
		System.out.println("The menu :");
		System.out.println("0. Exit.");
		System.out.println("1. Print menu again.");
		System.out.println("2. Prime count matrix.");
		System.out.println("3. Germain prime numbers in range.");
		System.out.println("4. Layers printing.");
		int userinput = BasicIO.ReadInteger("Please enter your choice :\n", 0, 4); //Receives the user's choice from the suggested menu 
		return (userinput);
	}

	public static void firstLineOfMatrix(int firstRowNum) {//Prints the first row of the matrix in "prime count matrix"(the smaller number+9 of the following numbers)
		System.out.format("%7s", "");
		for (int i = 0; i < 10; i++)
		{
			System.out.format("%7s", (firstRowNum + i));
		}
	}
	public static int countCommonPrimes(int matrixNum1, int matrixNum2) {//counts the number of common prime dividers of the 2 numbers the user input
		int count = 0;
		while (matrixNum1 % 2 == 0 && matrixNum2 % 2 == 0) //counts the amount of "2" (the only even prime number) , both nums have
		{
			matrixNum2 = matrixNum2 / 2;
			matrixNum1 = matrixNum1 / 2;
			count++;
		}
		for (int i = 3; i <= matrixNum2; i += 2) 
		{ //counts the amount of common odd prime dividers the 2 nums have 
			if (matrixNum1 % i == 0 && matrixNum2 % i == 0) 
			{
				matrixNum2 = matrixNum2 / i;
				matrixNum1 = matrixNum1 / i;
				count++;
				i-=2;
			}
		}
		return (count);
	}

	public static boolean checkPrime(int integer) {// checks whether an integer is prime or not.
		boolean t = true;
		if (integer == 2)
			return (t);
		if (integer % 2 == 0) // check if n is a multiple of 2
		{
			t = false;
			return (t);
		}
		else 
		{ 
			for (int i = 3; i * i <= integer; i += 2) { // if not, then just check the odds
				if (integer % i == 0)
					t = false;
			}
		}
		return (t);
	}

	public static void germain_numbers(int firstInput, int secondInput) {//Prints the germain prime numbers within the given range 
		int count = 1;
		if (firstInput > secondInput) 
		{
			for (int i = firstInput; i >= secondInput; i--) //prints the germian num from bigger to smaller in the given range
				if ((checkPrime(i) == true) && (checkPrime((i * 2) + 1) == true)) 
				{
					System.out.println(count + ". Germain prime number in the range is " + i + ".");
					count++;
				}
				else
					System.out.print("");
		} 
		else
			for (int i = firstInput; i <= secondInput; i++) //prints the germian num from smaller to bigger in the given range
				if ((checkPrime(i) == true) && (checkPrime((i * 2) + 1) == true)) 
				{
					System.out.println(count + ". Germain prime number in the range is " + i + ".");
					count++;
				} 
				else 
				{
					System.out.print("");
				}
		if (count == 1)
			System.out.println("There are no Germain prime numbers between " + firstInput + " and " + secondInput + ".");

	}
	public static void layersprinting (int height,int width)//Displays a matrix of "O"s(the user inputs the size) 
	{                                                       //and fills it with 3X3 square matrixes
		int numOfORows=1,numOfOCoulmns=1,matrixInW;
		switch(height%3)//counts the number of O rows (1-3 rows)
		{
		case 0:
			numOfORows=3;
			break;
		case 1:
			numOfORows=2;
			break;
		case 2:
			numOfORows=1;
		}
		switch(width%3)// counts the number of O columns (1-3 columns)
		{
		case 0:
			numOfOCoulmns=3;
			break;
		case 1:
			numOfOCoulmns=2;
			break;
		case 2:
			numOfOCoulmns=1;
		}
		for(int l=0;l<numOfORows;l++)//prints the O's in the rows
		{
			for(int j=0;j<width;j++)
			{
				System.out.format("O");
			}
			System.out.println("");
		}
		matrixInW=width-2*numOfOCoulmns;//count the number of squares that can fit into the matrix.
		if(numOfOCoulmns==2)
		{
			matrixInW=matrixInW+1;
			width++;
		}
		if(numOfOCoulmns==3)
		{
			matrixInW=matrixInW+2;
			width+=2;
		}
		for(int l=numOfORows;l<(height-numOfORows);l++)//prints the O's in the columns
		{
			for(int k=0;k<=width;k++)
			{
				if(k<numOfOCoulmns||k>(matrixInW+numOfOCoulmns))
				{
					System.out.format("O");
				}
				if(k>=numOfOCoulmns&&k<=matrixInW&&(k-numOfOCoulmns)%3==(l-numOfORows)%3)
				{
					System.out.format("\\");
				}

				if(k>=numOfOCoulmns&&k<=matrixInW&&(k-numOfOCoulmns)%3>(l-numOfORows)%3)
				{
					System.out.format("+");
				}

				if(k>=numOfOCoulmns&&k<=matrixInW&&(k-numOfOCoulmns)%3<(l-numOfORows)%3)
				{
					System.out.format("-");
				}
			}
			System.out.println("");
		}
		if(numOfOCoulmns==3)
		{
			width-=2;
		}
		if(numOfOCoulmns==2)
		{
			width--;
		}
		for(int l=0;l<numOfORows;l++)
		{
			for(int j=0;j<width;j++)
			{
				System.out.format("O");
			}
			System.out.println("");
		}
		System.out.println("");
	}
	public static void main(String[] args) {
		int choice = printmenu();
		while (choice!=0) // allows all choices in the menu while the user doesn't want to leave the program (by pressing "0") 
		{
			switch (choice) 
			{
			case 1: //in case the user chose "1" - prints the menu again
				choice = printmenu();	
				break;
			case 2: //in case the user chose "2" - displays the common prime dividers of the 2 nums the user input, in a matrix
				int min,max;
				int matrixN1 = BasicIO.ReadInteger("Please enter the 1st positive number ( up to 5 digits ) :\n", 1,
						99999);
				int matrixN2 = BasicIO.ReadInteger("Please enter the 2nd positive number ( up to 5 digits ) :\n", 1,
						99999);
				if (matrixN1 < matrixN2) 
				{
					max = matrixN2;
					min = matrixN1;
				} 
				else 
				{
					max = matrixN1;
					min = matrixN2;
				}
				firstLineOfMatrix(min);
				System.out.println("");
				for (int i = 0; i < 19; i++) 
				{
					System.out.format("%7d", max + i);
					for (int j = 0; j < 10; j++) 
					{
						System.out.format("%7d", countCommonPrimes(max + i, min + j));
					}
					System.out.println("");
				}
				choice = BasicIO.ReadInteger("Now enter a new menu input ( enter 1 for re-printing the menu ) :\n", 0,
						4);
				break;
			case 3: //in case the user chose "3" - displays the germain numbers within the user's input range
				int firstInput = BasicIO.ReadInteger("Please enter the first number for germain prime range :\n", 1,
						99999);
				int secondInput = BasicIO.ReadInteger("Please enter the second number for germain prime range :\n", 1,
						99999);
				germain_numbers(firstInput, secondInput);
				choice = BasicIO.ReadInteger("Now enter a new menu input ( enter 1 for re-printing the menu ) :\n", 0,
						4);
				break;
			case 4: //in case the user chose "4" - Displays a matrix of "O"s(the user inputs the size)
				//and fills it with 3X3 square matrixes
				int height = BasicIO.ReadInteger("Please enter the square height, range 7-20 :\n" ,7,20);// the height the user input
				int width = BasicIO.ReadInteger("Please enter the square width, range 7-20 :\n",7,20); // the width the user inputs
				layersprinting (height,width);
				choice = BasicIO.ReadInteger("Now enter a new menu input ( enter 1 for re-printing the menu ) :\n", 0,
						4);
				break;
			}
		}//while(choice!=0)
		if (choice==0);
		System.out.print("bye bye !!\n");
	}
}

